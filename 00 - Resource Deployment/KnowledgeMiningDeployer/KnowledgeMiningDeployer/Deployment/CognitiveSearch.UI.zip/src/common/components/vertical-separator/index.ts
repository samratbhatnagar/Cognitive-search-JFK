export { VerticalSeparator } from "./vertical-separator.component";
