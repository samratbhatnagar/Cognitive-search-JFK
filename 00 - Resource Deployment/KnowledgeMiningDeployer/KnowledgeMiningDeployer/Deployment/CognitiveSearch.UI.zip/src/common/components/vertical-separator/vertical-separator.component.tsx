import * as React from "react";
const style = require("./vertical-separator.style.scss");

export const VerticalSeparator = () => <div className={style.verticalSeparator}/>