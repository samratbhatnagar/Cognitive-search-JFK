export * from "./hocr-proofreader.component";
