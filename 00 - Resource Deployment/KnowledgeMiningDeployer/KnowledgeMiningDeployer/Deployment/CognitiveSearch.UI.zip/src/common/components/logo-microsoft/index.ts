export { LogoMicrosoftComponent } from "./logo.component";
