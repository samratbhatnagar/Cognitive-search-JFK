export * from "./hocr-preview.component";
export { HocrPreviewStyleMap } from "./hocr-preview.style";
export { ZoomMode } from "./hocr-page.component";
