export { LogoJFKComponent } from "./logo.component";
