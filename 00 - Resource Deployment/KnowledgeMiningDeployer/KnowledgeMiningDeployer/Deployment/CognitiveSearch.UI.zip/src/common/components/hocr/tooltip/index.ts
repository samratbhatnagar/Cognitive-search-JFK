export { TooltipComponent } from "./tooltip.component";
