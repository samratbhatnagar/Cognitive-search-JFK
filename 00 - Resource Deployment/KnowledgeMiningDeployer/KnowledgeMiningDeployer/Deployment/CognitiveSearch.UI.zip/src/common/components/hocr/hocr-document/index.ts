export * from "./hocr-document.component";
export { HocrDocumentStyleMap } from "./hocr-document.style";
