# AzApi

![AzApi Diagram](az-api.png)