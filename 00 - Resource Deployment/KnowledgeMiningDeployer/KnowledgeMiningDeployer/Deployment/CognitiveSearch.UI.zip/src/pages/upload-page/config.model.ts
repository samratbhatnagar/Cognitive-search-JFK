/**
 * Object that represents API conection parameters.
 */

export interface UploadConfig {
  protocol: string;
  serviceUrl: string;
}
