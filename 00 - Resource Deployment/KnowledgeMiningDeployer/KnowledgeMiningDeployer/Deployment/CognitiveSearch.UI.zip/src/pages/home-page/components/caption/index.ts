export { CaptionComponent } from "./caption.component";
