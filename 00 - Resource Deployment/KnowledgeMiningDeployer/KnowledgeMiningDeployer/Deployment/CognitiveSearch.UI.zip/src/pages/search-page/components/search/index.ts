export { SearchComponent } from "./search.component";
