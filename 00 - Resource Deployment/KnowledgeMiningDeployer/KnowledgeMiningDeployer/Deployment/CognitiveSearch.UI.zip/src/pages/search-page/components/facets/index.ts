export { FacetViewComponent } from "./facet-view.component";
