export { PlaceholderComponent } from "./placeholder.component";
