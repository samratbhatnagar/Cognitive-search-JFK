export { PageBarComponent } from "./page-bar.component";
