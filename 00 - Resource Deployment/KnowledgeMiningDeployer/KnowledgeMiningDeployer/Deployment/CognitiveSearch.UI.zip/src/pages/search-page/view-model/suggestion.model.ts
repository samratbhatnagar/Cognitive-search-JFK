export interface Suggestion {
  text: string;
}

export type SuggestionCollection = Suggestion[];
