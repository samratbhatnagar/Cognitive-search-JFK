export interface Filter {
  fieldId: string;  
  store: any;
}

export type FilterCollection = Filter[];
