export * from "./spacer.component";
