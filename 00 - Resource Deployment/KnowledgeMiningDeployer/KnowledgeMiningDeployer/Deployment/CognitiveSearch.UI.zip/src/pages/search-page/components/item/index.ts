export { ItemCollectionViewComponent } from "./item-collection-view.component";
