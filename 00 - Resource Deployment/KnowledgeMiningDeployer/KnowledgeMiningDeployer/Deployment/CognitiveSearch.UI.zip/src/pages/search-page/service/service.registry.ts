import { Service, CreateService } from "../service";
import { azServiceConfig } from "./az";

export const azService = CreateService(azServiceConfig);
