export { DetailPageContainer } from "./detail-page.container";
export { DetailRoute, DetailRouteState, detailPath } from "./detail-page.route";